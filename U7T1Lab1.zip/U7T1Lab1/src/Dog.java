public class Dog {
    private String name;

    public Dog(String name)
    {
     this.name = name;
    }
    public void setName(String newName)
    {
        this.name = newName;
    }

    public String getName()
    {
        return name;
    }

    public void bark()
    {
        System.out.println("woof!");
    }

    public String toString()
    {
        String a = "bruh";
        return a;
    }
}
